var bot1,bot2,bot3,quant,finval,dado
finval=0
document.getElementById("but1").addEventListener("click", function() {
    quant=Number(prompt('qual a quantidade de dados?'))
    for(var cont=1;cont<=quant;cont++){
        dado=Math.ceil(Math.random()*2)
        finval=finval+dado
        document.write(`valor do dado d2: ${dado}<br>`)           
    }
    document.write(`valor final ${finval}`)
});




document.getElementById("but2").addEventListener("click", function() {
    quant=Number(prompt('qual a quantidade de dados?'))
    for(var cont=1;cont<=quant;cont++){
        dado=Math.ceil(Math.random()*4)
        finval=finval+dado
        document.write(`valor do dado d4: ${dado}<br>`)           
    }
    document.write(`valor final ${finval}`)
});



document.getElementById("but3").addEventListener("click", function() {
    quant=Number(prompt('qual a quantidade de dados?'))
    for(var cont=1;cont<=quant;cont++){
        dado=Math.ceil(Math.random()*6)
        finval=finval+dado
        document.write(`valor do dado d6: ${dado}<br>`)           
    }
    document.write(`valor final ${finval}`)
});



document.getElementById("but4").addEventListener("click", function() {
    quant=Number(prompt('qual a quantidade de dados?'))
    for(var cont=1;cont<=quant;cont++){
        dado=Math.ceil(Math.random()*8)
        finval=finval+dado
        document.write(`valor do dado d8: ${dado}<br>`)           
    }
    document.write(`valor final ${finval}`)
});



document.getElementById("but5").addEventListener("click", function() {
    quant=Number(prompt('qual a quantidade de dados?'))
    for(var cont=1;cont<=quant;cont++){
        dado=Math.ceil(Math.random()*10)
        finval=finval+dado
        document.write(`valor do dado d10: ${dado}<br>`)           
    }
    document.write(`valor final ${finval}`)
});



document.getElementById("but6").addEventListener("click", function() {
    quant=Number(prompt('qual a quantidade de dados?'))
    for(var cont=1;cont<=quant;cont++){
        dado=Math.ceil(Math.random()*12)
        finval=finval+dado
        document.write(`valor do dado d12: ${dado}<br>`)           
    }
    document.write(`valor final ${finval}`)
});



document.getElementById("but7").addEventListener("click", function() {
    quant=Number(prompt('qual a quantidade de dados?'))
    for(var cont=1;cont<=quant;cont++){
        dado=Math.ceil(Math.random()*20)
        finval=finval+dado
        document.write(`valor do dado d20: ${dado}<br>`)           
    }
    document.write(`valor final ${finval}`)
});



document.getElementById("but8").addEventListener("click", function() {
    quant=Number(prompt('qual a quantidade de dados?'))
    for(var cont=1;cont<=quant;cont++){
        dado=Math.ceil(Math.random()*100)
        finval=finval+dado
        document.write(`valor do dado d100: ${dado}<br>`)           
    }
    document.write(`valor final ${finval}`)
});


